<!-- フッター -->
<footer>
    <div class="footer_social">
       <a href="https://twitter.com"><img src="<?php echo get_template_directory_uri(); ?>/button-twitter.png" class="sns"></a>
       <a href="https://www.facebook.com"><img src="<?php echo get_template_directory_uri(); ?>/button-facebook.png" class="sns"></a>
       <span>SNSはこちらからチェック!</span>
      </div>
      <div class="footer-nav">
        <a class="footer-navcontnt" href="<?php echo home_url(); ?>/top">TOP</a>
        <a class="footer-navcontnt" href="<?php echo home_url(); ?>/category/purchase">買取について</a>
        <a class="footer-navcontnt" href="<?php echo home_url(); ?>/category/sale">販売について</a>
        <a class="footer-navcontnt" href="<?php echo home_url(); ?>/abot">会社概要</a>
        <a class="footer-navcontnt" href="<?php echo home_url(); ?>/contact">お問い合わせ</a>
        <a class="footer-navcontnt" href="<?php echo home_url(); ?>/news">アクセス</a>
      </div>
      <div class="map">
       <div class="leftcontent">
        <div class="addressinfo">
         <p class="access">ACCESS  </p>
         <p class="mod1">
          〒000-000<br>  愛知県名古屋市中村区名駅南2丁目
         </p>
        </div>
        <p class="access">CONTACT  </p><br>
        <div class="flex">
          <div class="childcontent">
           <p class="mod0">
            電話でのご相談は下記より
           </p>
           <p class="mod1">
            052-999-9999(10～19時定休日除く)
           </p>
          </div>
          <div class="childcontent">
           <p class="mod0">
             フォームでのお問い合わせは<span>24時間</span>対応!
           </p>
            <a href="index.html"><img class="contact-button" src="<?php echo get_template_directory_uri(); ?>/contact-or500.png"></a> 
           </p>
          </div>
        </div>
       </div>
       <div class="rightcontent">
        <p class="access">MAP    </h3>
        <p><iframe class="gmap" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12967.099651228138!2d139.6962182!3d35.6579169!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7abbc1a9d7d575eb!2z5qCq5byP5Lya56S-U0FNVVJBSQ!5e0!3m2!1sja!2sjp!4v1651043809252!5m2!1sja!2sjp"></iframe></p>
        <p id="info">○○公園西口正面にございます。ご不明な場合はお気軽にお問合せください。</p>
       </div> 
      </div>
     <div class="cr_text">
      Copyright &copy; SKホールディングス.
     </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <!-- slickの読み込み -->
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/script111.js"></script>
 <?php wp_footer()?>
</body>
</html>
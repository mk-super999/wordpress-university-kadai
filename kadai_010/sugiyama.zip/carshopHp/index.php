<?php get_header();?>
<main>
 <section id="movecontent">
    <div class="carousel">
        <div><a href=""><img class="carousel-img" src="<?php echo get_template_directory_uri(); ?>/carousel1.png" ></a></div>
        <div><a href=""><img class="carousel-img" src="<?php echo get_template_directory_uri(); ?>/carousel2.png" ></a></div>
        <div><a href=""><img class="carousel-img" src="<?php echo get_template_directory_uri(); ?>/carousel3.png" ></a></div>
    </div>
    <div class="used_carsection">
     <div class="toumei">
      <!-- 在庫車一覧へ飛ぶ -->
      <p class="mod5">中古車を探す</p>
      <div id="usedcarbuttonsection">
      <a href="https://www.carsensor.net/usedcar/search.php?STID=CS210610&AR=48&KW=%E6%9D%B1%E6%84%9B%E7%9F%A5%E6%97%A5%E7%94%A3">
        <img src="<?php echo get_template_directory_uri(); ?>/usedcar.png" class="usedcarbutton">
      </a>
      </div>
      <p class="mod4">ボディタイプから探す</p>
       <ul class="type-area" >
        <li>
         <a href="https://www.carsensor.net/usedcar/btO/aichi/index.html">
          <div class="childbox">
           <span class="img">
             <img src="<?php echo get_template_directory_uri(); ?>/type_sedan.svg">
           </span>
           <p class="type-areaP">セダン</p>
          </div>
         </a>
        </li>
        <li>
          <a href="https://www.carsensor.net/usedcar/btO/aichi/index.html">
           <div class="childbox">
            <span class="img">
              <img src="<?php echo get_template_directory_uri(); ?>/type_compact.svg">
            </span>
            <p class="type-areaP">ハッチバック</p>
           </div>
          </a>
         </li>
         <li>
          <a href="https://www.carsensor.net/usedcar/btO/aichi/index.html">
           <div class="childbox">
            <span class="img">
              <img src="<?php echo get_template_directory_uri(); ?>/type_sporty.svg">
            </span>
            <p class="type-areaP">オープン</p>
           </div>
          </a>
         </li>
         <li>
          <a href="https://www.carsensor.net/usedcar/btO/aichi/index.html">
           <div class="childbox">
            <span class="img">
              <img src="<?php echo get_template_directory_uri(); ?>/type_wagon.svg">
            </span>
            <p class="type-areaP">その他</p>
           </div>
          </a>
         </li>
         <li>
          <a href="https://www.carsensor.net/usedcar/btO/aichi/index.html">
           <div class="childbox">
            <span class="img">
              <img src="<?php echo get_template_directory_uri(); ?>/type_suv.svg">
            </span>
            <p class="type-areaP">ハッチバック</p>
           </div>
          </a>
         </li>
       </ul>
     </div>
    </div>
   <div class="toumei">
    <div class="review">
     <div class="toumei">
      <p class="mod5">販売実績</p>
      <p class="mod3 info">この度は数ある販売店の中から<br>
        弊社在庫車両をご成約いただき<br>
        誠にありがとうございました。<br>
      </p>
      <div class="customerinfo">
        <div class="background">
        <!-- 販売実績は投稿一覧に飛ばし画像とタイトル分を引っ張ってきたい -->
        <?php
               //取得したい投稿記事などの条件を引数として渡す
               $args = array(
                   // 投稿タイプ
                   'post_type'     => 'post',
                   // カテゴリー名
                   'category_name' => 'sale',
                   // 1ページに表示する投稿数
                   'posts_per_page' => 6,
               );
               // データの取得
               $posts = get_posts($args);
       ?>


               <!--  ループ -->
                <?php foreach($posts as $post):?>
                <?php setup_postdata($post); ?>
                  <div class="customerinfochild">
                 <a href="<?php echo get_permalink();?>">
                 <?php echo get_the_date();?>
                 <div class="customerinfophoto">
                     <?php the_post_thumbnail(); ?>
                   </div>
                 </a>                 

                 
                 <a href="<?php the_permalink(); ?>"> 
                  <?php the_title();?>
                 </a>
               <?php endforeach;?>
               
               <?php wp_reset_postdata();?> 
              </div>
      <a href="">
       <img src="<?php echo get_template_directory_uri(); ?>/more.png" id="more" class="contact-button">
      </a>

    </div>
     </div>
    </div>
 </section>
</main>

<!-- フッター -->
<?php get_footer();?>
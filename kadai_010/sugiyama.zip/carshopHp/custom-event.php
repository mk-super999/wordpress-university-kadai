<?php
 /*
 Template Name: イベント投稿ページ
 Template Post Type: post
 */
 ?>


<?php get_header(); ?>

<div class="mainbox">
<div class="leftcontent4">
<?php if (have_posts()):
              while (have_posts()) :
                 the_title(); 
                 the_post();
                 the_content();
                
              endwhile;
           endif; ?>

<?php previous_post_link(); ?>
<?php next_post_link(); ?>
</div>
<div class="rightcontent4">
<?php get_sidebar(); ?>
    
    
</div>
</div>
<?php get_footer(); ?>

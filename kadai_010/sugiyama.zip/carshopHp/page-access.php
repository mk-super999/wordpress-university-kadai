
<?php get_header();?>

<main>

</main>
<!-- フッター -->
<div class="clear">
<div class="mapinfo1">
 <div class="adressinfo1">
  <p class="mod1">〒000-000<br>  愛知県名古屋市中村区名駅南2丁目</p>
  <img class="photo2" src="<?php echo get_template_directory_uri(); ?>/shop2.jpg"> 
  <img class="photo2" src="<?php echo get_template_directory_uri(); ?>/shop2.jpg"> 
 </div>

 <div class="right2">
  <iframe class="gmap2" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12967.099651228138!2d139.6962182!3d35.6579169!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7abbc1a9d7d575eb!2z5qCq5byP5Lya56S-U0FNVVJBSQ!5e0!3m2!1sja!2sjp!4v1651043809252!5m2!1sja!2sjp"></iframe>
 </div>
</div>
</div>
<?php get_footer(); ?>


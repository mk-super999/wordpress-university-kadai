<?php get_header(); ?>

<!-- getsidebarをやるとなぜかpurchaseが表示されなくなる -->
<?php if (have_posts()):
              while (have_posts()) :
                 the_post();
                 the_content();
              endwhile;
           endif; ?>
           
    <div class="review3">
     <div class="toumei2">
      <p class="mod5">販売実績</p>
  
  
      <div class="customerinfo">
      <div class="background3">

        <!-- 販売実績は投稿一覧に飛ばし画像とタイトル分を引っ張ってきたい -->
       <?php
               //取得したい投稿記事などの条件を引数として渡す
               $args = array(
                   // 投稿タイプ
                   'post_type'     => 'post',
                   // カテゴリー名
                   'category_name' => 'sale',
                   // 1ページに表示する投稿数
                   'posts_per_page' => 9,
               );
               // データの取得
               $posts = get_posts($args);
       ?>

               <!--  ループ -->
                <?php foreach($posts as $post):?>
                <?php setup_postdata($post); ?>
                  <div class="flex2">
                    <a href="<?php the_permalink(); ?>"> 
                     <?php the_title(); ?>
                     
                     <?php the_post_thumbnail('small',['class'=>'thumbnail']); ?>
                    </a> 
                   </div>   
               <?php endforeach;?>
               <?php wp_reset_postdata();?> 
              
                 
        
         </div>
      
      
     </div>
     <p class="mod8">※保証に関しまして<br>●期間中は何度でも使用可　※累積上限金額あり<br>●最長１０年の有料保証もご用意。充実の保証範囲（318項目）1・2・3・10年からお選びいただけます※車両により加入条件が異なります</p>
     <a href="" ><p class="nextpage">次へ進む</p></a>
      </div>
     </div>
    </div>
    
<?php get_footer(); ?>
<?php
 /*
 Template Name: イベント投稿ページ
 Template Post Type: post
 */
 ?>


<?php get_header(); ?>

<div class="mainbox">
<div class="leftcontent4">

<?php the_post();?> 
  <div class="photozone">
   <div class="title5"><?php the_title();?></div> 
    <?php the_content();?>
    <?php previous_post_link(); ?>
    <?php next_post_link(); ?>
  </div>
</div>
<div class="rightcontent4">
<?php get_sidebar(); ?>
    
    
</div>
</div>
<?php get_footer(); ?>

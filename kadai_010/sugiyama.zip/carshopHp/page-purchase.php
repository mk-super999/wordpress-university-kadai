<?php get_header(); ?>
<!-- getsidebarをやるとなぜかpurchaseが表示されなくなる -->
<?php if (have_posts()):
              while (have_posts()) :
                 the_post();
                 the_content();
              endwhile;
           endif; ?>
           
           <div class="toumei">
    <div class="review">
     <div class="toumei">
      <p class="mod5">販売実績</p>
      <p class="mod3 info">この度は数ある販売店の中から<br>
        弊社在庫車両をご成約いただき<br>
        誠にありがとうございました。<br>
      </p>
      <div class="customerinfo">
      <div class="background">
       <div class="box">
        <!-- 販売実績は投稿一覧に飛ばし画像とタイトル分を引っ張ってきたい -->
        <?php
               //取得したい投稿記事などの条件を引数として渡す
               $args = array(
                   // 投稿タイプ
                   'post_type'     => 'post',
                   // カテゴリー名
                   'category_name' => 'purchase',
                   // 1ページに表示する投稿数
                   'posts_per_page' => 6,
               );
               // データの取得
               $posts = get_posts($args);
       ?>

               <!--  ループ -->
                <?php foreach($posts as $post):?>
                <?php setup_postdata($post); ?>
                  <div class="flex1">
                    <a href="<?php the_permalink(); ?>"> 
                     <?php the_title(); ?>
                     
                     <?php the_post_thumbnail('large',['class'=>'thumbnail']); ?>
                    </a> 
                   </div>   
               <?php endforeach;?>
               <?php wp_reset_postdata();?> 
                </div>    
         <a href="">
           <img src="<?php echo get_template_directory_uri(); ?>/more.png" id="more" class="contact-button">
         </a>
         </div>
      
      
     </div>

      </div>
     </div>
    </div>
    
<?php get_footer(); ?>
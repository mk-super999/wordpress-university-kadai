<!DOCTYPE html>
<html lang="ja">
<head>
 <meta charset="UTF-8">
 <meta name= description content= "お客様とクルマとの最高の出会いを実現いたします。販売、買取は弊社にお任せください！">
 <title>○○○○株式会社</title>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
 <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&family=Noto+Sans+JP:wght@100;200;400&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">

<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/styles/bootstrap4/bootstrap.min.css" />
   <link href="<?php echo get_template_directory_uri(); ?>/plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
   <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/styles/main_styles.css" />

<?php wp_head(); ?>
</head>

<body>
<header>  
    <div class="companylogo">
      <a href="index.html">
        <img src="<?php echo get_template_directory_uri(); ?>/logo1.png" id="logo">
      </a>
    </div>
  <div class="nav">
    <a class="navcontent"  href="<?php echo home_url(); ?>/top">TOP</a>
    <a class="navcontent"href="<?php echo home_url(); ?>/purchase">買取について</a>
    <a class="navcontent"href="<?php echo home_url(); ?>/sale">販売について</a>
    <a class="navcontent"href="<?php echo home_url(); ?>/about">会社概要</a>
    <a class="navcontent"href="<?php echo home_url(); ?>/contact">お問い合わせ</a>
    <a class="navcontent"href="<?php echo home_url(); ?>/access">アクセス</a>
  </div> 
  <!-- スマホ用 -->
  <img id="menu-sp" src="<?php echo get_template_directory_uri(); ?>/bars_24.png" alt="ナビゲーションを開く" >
  <div class="navsp">
    <a class="close"><img src="<?php echo get_template_directory_uri(); ?>/button-close.png" class="closebutton"></a>
    <a class="navcontent"  href="<?php echo home_url(); ?>/top">TOP</a>
    <a class="navcontent" href="<?php echo home_url(); ?>/purchase">買取について</a>
    <a class="navcontent" href="<?php echo home_url(); ?>/sale">販売について</a>
    <a class="navcontent" href="<?php echo home_url(); ?>/about">会社概要</a>
    <a class="navcontent" href="<?php echo home_url(); ?>/contact">お問い合わせ</a>
    <a class="navcontent" href="<?php echo home_url(); ?>/access">アクセス</a>
    
    
  </div> 
  

  
</header>
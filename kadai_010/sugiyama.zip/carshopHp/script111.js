   // カルーセル
   $('.carousel').slick({
    autoplay: true,
    dots: true,
    infinite: true,
    autoplaySpeed: 2000,
    arrows: false,
  });


  var prop = {'box-shadow': '0 0 20px white',
                 'opacity': 1,};
  var nonprop = {'box-shadow': '0 0 0px',
                 'opacity': 0.7,};
  var prop2 = {'box-shadow': '0 0 20px gold',
                 'opacity': 0.8,};
  var nonprop2 = {'box-shadow': '0 0 0px',
                 'opacity': 1,}; 
  var prop3 = {'margin-right':'50px', 'opacity':'1','background-color':'navy',};
  var cancelprop3 = {'margin-right':'0px', 'opacity':'0.7','background-color':'gray'};

// Gmapの影
$(function(){
  $('.gmap').on('mouseenter',()=>{
    $('.gmap').toggleClass('sample');
  })
  $('.gmap').on(' mouseleave',()=>{
    $('.gmap').removeClass('sample');
  })
  $('.contact-button').on('mouseenter',()=>{
    $('.contact-button').toggleClass('sample2');
  })
  $('.contact-button').on('mouseleave',()=>{
    $('.contact-button').removeClass('sample2');
  })

  $('.usedcarbutton').on('mouseenter',()=>{
    $('.usedcarbutton').css(prop2);
  })
  $('.usedcarbutton').on('mouseleave',()=>{
    $('.usedcarbutton').css(nonprop2);
  })
  $('.btn-fix').mouseover(function(){
     $('.btn-fix').css(prop3);
  });
  $('.btn-fix').on('mouseleave',()=>{
    $('.btn-fix').css(cancelprop3);
 });
 $('.btn-fix2').mouseover(function(){
  $('.btn-fix2').css(prop3);
});
$('.btn-fix2').on('mouseleave',()=>{
 $('.btn-fix2').css(cancelprop3);
});
$('.btn-fix3').mouseover(function(){
  $('.btn-fix3').css(prop3);
});
$('.btn-fix3').on('mouseleave',()=>{
 $('.btn-fix3').css(cancelprop3);
});
 
$('#menu-sp').on('mouseover',()=>{
  $('#menu-sp').css('opacity', '1.0');
 });
$('#menu-sp').on('click',()=>{
  $('.navsp').css('display','none',)
});
})

$(function(){
  $('.navsp').hide();
  $('#menu-sp').on('click',function(){
    $(".navsp").fadeIn("slow");
  });
  $('.close').on('click',()=>{
    $('.navsp').fadeOut("slow")
   })
})







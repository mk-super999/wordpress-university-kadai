<?php get_header();?>

<main>

<?php if (have_posts()):
              while (have_posts()) :
                 the_post();
                 the_content();
              endwhile;
           endif; ?>
<table class="kaisha">
<tr>
<th>会社名</th>
<td>Car-tecK株式会社</td>
</tr>
<tr>
<th>代表</th>
<td>杉山健太</td>
</tr>
<tr>
<th>設立</th>
<td>2023年12月</td>
</tr>
<tr>
<th>所在地</th>
<td>愛知県名古屋市中区栄0-0-0</td>
</tr>
<tr>
<th>電話</th>
<td>052-0000-0000</td>
</tr>
<tr>
<th>内容</th>
<td>中古車販売・車検整備・カスタム・新車販売</td>
</tr>
</table>
</main>
<!-- フッター -->

<?php get_footer(); ?>

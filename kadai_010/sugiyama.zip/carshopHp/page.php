<?php
/**
 * Template Name: kotei
 */
get_header(); ?>

<!-- getsidebarをやるとなぜかpurchaseが表示されなくなる -->
<?php if (have_posts()):
              while (have_posts()) :
                 the_post();
                 the_content();
              endwhile;
           endif; ?>
 <div class="toumei">
    <div class="review2">
     <div class="toumei">
      <p class="mod6">買取実績</p>
      <p class="mod3 info">この度は数ある販売店の中から<br>
        弊社にお売りいただき<br>
        誠にありがとうございました。<br>
      </p>
      <div class="customerinfo">
      <div class="background2">
       <div class="box2">
        <!-- 販売実績は投稿一覧に飛ばし画像とタイトル分を引っ張ってきたい -->
        <?php
               //取得したい投稿記事などの条件を引数として渡す
               $args = array(
                   // 投稿タイプ
                   'post_type'     => 'post',
                   // カテゴリー名
                   'category_name' => 'purchase',
                   // 1ページに表示する投稿数
                   'posts_per_page' => 3,
               );
               // データの取得
               $posts = get_posts($args);
       ?>

               <!--  ループ -->
                <?php foreach($posts as $post):?>
                <?php setup_postdata($post); ?>
                  <div class="flex1">
                    <a href="<?php the_permalink(); ?>"> 
                     <?php the_title(); ?>
                     
                     <?php the_post_thumbnail('large',['class'=>'thumbnail']); ?>
                    </a> 
                   </div>   
               <?php endforeach;?>
               <?php wp_reset_postdata();?> 
                </div>    
         <a href="">
           <img src="<?php echo get_template_directory_uri(); ?>/more.png" id="more" class="contact-button">
         </a>
         </div>
      
      
     </div>

      </div>
     </div>
    </div>
    
    <div class="container">
        <h1>簡易買取査定フォーム</h1>
        <form id="contact-form">
            <label for="name">お名前:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">メールアドレス:</label>
            <input type="email" id="email" name="email" required>

            <label for="email">お車のメーカー:</label>
            <input type="email" id="email" name="maker" required>

            <label for="email">お車の社名:</label>
            <input type="email" id="email" name="carname" required>

            <label for="email">年式:</label>
            <input type="email" id="email" name="nennsiki" required>
            
            <label for="email">走行距離</label>
            <input type="email" id="email" name="soukou" required>

            <label for="email">グレード:</label>
            <input type="email" id="email" name="grade" required>

            <label for="message">装備、カスタム、備考:</label>
            <textarea id="message" name="message" required></textarea><br>

            <label for="message">写真:</label>
            <div class="photobox">
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc"> 
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc">
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc"> 
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc">
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc"> 
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc">
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc"> 
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc">
            <input type="file" name="example" accept=".png, .jpg, .jpeg, .pdf, .doc"><br>
            <p id="art">※JPG、GIF、PNGファイルが添付可能※容量制限は1枚あたり1MB以下となります</p>
            </div></br>
            <br>
            <button type="submit">送信</button>
        </form>
    </div>
   

   
<?php get_footer(); ?>